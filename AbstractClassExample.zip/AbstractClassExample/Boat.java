class Boat extends Vehicle
{
public int fuelConsumption()
{
	return 100;
}
}