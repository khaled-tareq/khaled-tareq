class Car extends Vehicle
{
public int fuelConsumption()
{
	return 400;
}
}