abstract class Vehicle
{
	private int speed;
	public abstract int fuelConsumption();
	public void print()
	 {
		 System.out.println("Speed=" + speed);
	 }
}