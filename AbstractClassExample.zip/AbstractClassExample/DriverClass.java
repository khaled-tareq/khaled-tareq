class DriverClass
{
	public static void main(String a[])
	{
      Point p1 = new Point();
      p1.setPoint(10,20);
      System.out.println("p1 " + p1.toString());
      Point p2 = new Point();

      Boolean f=p1.equals(p2);
      System.out.println(" p1 and p2, f=" + f);

      Point p3;
      p3=p1;
      f=p1.equals(p3);
      System.out.println("p1 and p3 are aliases, f=" + f);
	  p3.setPoint(100,200);
	  System.out.println("p1 " + p1.toString());
	}
}