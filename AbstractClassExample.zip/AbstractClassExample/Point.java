class Point extends Object
{
	private int x;
	private int y;
	public String toString()// Overriding
	{
		return "x=" + x + ", y=" + y;
	}
	public void setPoint(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
}